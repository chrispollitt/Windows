# Go-WinTask 

> Go wrapper for windows Task Scheduler CLI Tool (schtasks).

## Todo

- [x] Support exe arguments with spaces, e.g [-sd "word with spaces"].
- [ ] Support for remote systems, implement user/pass and system flags.
- [ ] Add wizard for create, change, query and delete.

